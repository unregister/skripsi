<?php
class Nusoap_lib
{
	function Nusoap_lib()
	{
		require_once("nusoap/lib/nusoap.php");	
	}
}